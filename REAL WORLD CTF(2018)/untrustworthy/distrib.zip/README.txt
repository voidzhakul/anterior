Hi there!

This is a Windows-based challenge trying to immitate some kind of real-world logical bug. You mission is to find the bug inside the server and use it to get the flag.

This is something you should remember, by your heart: the name of the account running your challenge is "realworld", with everything configured, as a normal user.

Distribution package breakdown :
1. README.txt - this readme file explains how the challenge works
2. deploy.bat - the deploy script we used to deploy the service, some details are removed.
3. sandbox.exe, jsoncpp.dll - the sandbox program used by the service to execute your binary, details can be found at https://github.com/marche147/sandbox
4. sandbox.json - sandbox configuration used by sandbox.exe. password of the user is not revealed.
5. server.exe - this executable providing RPC service (essential!)
6. LIBEAY32.dll - OpenSSL library used by server.exe, don't waste your time on this one.
7. server.pdb - symbol file of server.exe
8. fail_plugin.dll - This is one of the dependencies used by server.exe, this file [could be] important to you. :)

Since the aim of the challenge is not to frustrate you with this huge binary, I've attached the symbol file to distribution package. If you still feel frustrated, check out some source code at: https://github.com/marche147/wctf-game. You can find similar code there.

How the service.py (the challenge interface) works :
1. Players connect to the service, and the service asks you for a proof-of-work.
2. After verifing the proof-of-work, the service asks you for the executable.
3. The service saves your program A.
4. The service executes your binary using the sandbox.exe and the config in sandbox.json. (You won't have input to the program.)
5. The service dumps the output to you.
6. The service deletes your program A.

The service.py is running as SYSTEM, meanwhile the server.exe is running as normal user (realworld). If you want to have a shell running locally with SYSTEM privilege, try PsExec from SysInternals suite.
You can contact @shiki7 in IRC if you have any question. 

Some F.A.Q.s :

1. Q: My program cannot be started under the sandboxed environment. A: Try to tweak the parameters in sandbox.json, you should try to figure out what is limited by the sandbox. The solution should work under the sandboxed environment.
2. Q: I'm not getting output from the server even though my program does print something out. A: Maybe the reason for not receiving output is buffering. Solutions could be: (1) Disable `stdout` buffering. (2) Flush stream after print. (3) Remove code that forces your program to exit (e.g. ExitProcess, _exit).

I hope you'll enjoy solving this challenge. Good luck!

-- shiki7
