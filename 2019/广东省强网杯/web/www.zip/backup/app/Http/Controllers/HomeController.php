<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\File;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    public function uploads()
    {
	return view('auth.upload');
    }
	public function uploadss(Request $request,$key){
	   if($key!=<in database key>){die('sorry!');}

        if ($request->isMethod('post')) {

            $file = $request->file('files');
            if ($file->isValid()) {
                $originalName = $file->getClientOriginalName(); 
                $ext = $file->getClientOriginalExtension();     
                $realPath = $file->getRealPath();  
                $type = $file->getClientMimeType();
                $filecheck=new HomeController();
		        $filecheck->filecheck($realPath);
		        $filename = date('Y-m-d-H-i-s') . '-' . uniqid() . '.' . $ext;
		        $path=$file -> move(base_path().'/resources/views/auth/uploads',$originalName);  
            }
        }

        return view('home');
    }
	public function filecheck($filename){
		//waf
	}
}

