<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
   <meta charset="utf-8">
	<title>WEB</title>
	<meta name="description" content="">  
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <link rel="stylesheet" href="{{ asset('indexx/css/base.css') }}">  
   <link rel="stylesheet" href="{{ asset('indexx/css/main.css') }}">
   <link rel="stylesheet" href="{{ asset('indexx/css/vendor.css') }}">     

   <!-- script
   ================================================== -->   
	<script src="{{ asset('indexx/js/modernizr.js') }}"></script>
	<script src="{{ asset('indexx/js/pace.min.js') }}"></script>

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="favicon.png">

</head>

<body id="top">

	<!-- header 
   ================================================== -->

	<!-- intro section
   ================================================== -->
   <section id="intro">   

   	<div class="intro-overlay"></div>	

   	<div class="intro-content">
   		<div class="row">

   			<div class="col-twelve">

	   			<h5>Hello,Ctfer:)</h5>
<h1>Enjoy Laravel</h1>
	   			<p class="intro-position">
	   				<span>S0 FUN</span> 
	   			</p>

	   			<a class="button stroke smoothscroll"   href="/login">Click!</a>

	   		</div>  
   			
   		</div>   		 		
   	</div> <!-- /intro-content --> 

   	<ul class="intro-social">        
         <li><a href="#"><i class="fa fa-twitter"></i></a></li>
      </ul> <!-- /intro-social -->      	

   </section> <!-- /intro -->


   <!-- about section
   ================================================== -->
   

	

   <!-- footer
   ================================================== -->

   <div id="preloader"> 
    	<div id="loader"></div>
   </div> 

   <!-- Java Script
   ================================================== --> 
   <script src="{{ asset('indexx/js/jquery-2.1.3.min.js') }}"></script>
   <script src="{{ asset('indexx/js/plugins.js') }}"></script>
   <script src="{{ asset('indexx/js/main.js') }}"></script>

</body>

</html>
