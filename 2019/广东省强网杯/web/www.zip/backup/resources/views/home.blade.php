<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>WEB</title>
  <link href="{{ asset('mypage/style.css') }}" rel="stylesheet" type="text/css" />
 </head>
 <body>
  <div id="header">
   <div id="logo">
    <h1> SYStem Page</h1>
   </div>
  </div>
  <div id="container">
   <div id="sidebar">
    <h1>About CTF</h1>
    <p> <img src="{{ asset('mypage/images/author.png') }}" alt="" /> CTF（Capture The Flag）中文一般译作夺旗赛，在网络安全领域中指的是网络安全技术人员之间进行技术竞技的一种比赛形式。CTF起源于1996年DEFCON全球黑客大会，以代替之前黑客们通过互相发起真实攻击进行技术比拼的方式。</p>
    <h1>Our Slogan</h1>
    <p>Havefun:)</p>
   </div>

   <div id="content">
    <h1>About This Task</h1>
    <p>Looks so fun,right?</p><p>Enjoy This Game</p>
    <h1>Where is Flag</h1>
    <p>Flag Path:/flag_is_here</p>
    <ul>
    </ul>
   </div>
  </div>
  <br clear="all" />
 </body>
</html>
