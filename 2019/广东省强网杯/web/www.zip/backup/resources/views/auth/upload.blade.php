<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="author">
    <meta name="description" content="">
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data">
  {{ csrf_field() }}
  <div class="form-group">
     <label for="files">File input</label>
  </div>
   
</form>
</body>
</html>
